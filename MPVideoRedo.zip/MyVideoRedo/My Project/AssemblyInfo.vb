﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports MediaPortal.Common.Utils
' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: CompatibleVersion("1.10.000.0", "1.4.000.0")> 
<Assembly: UsesSubsystem("MP.SkinEngine")> 
<Assembly: UsesSubsystem("MP.Config")> 
<Assembly: AssemblyTitle("MyVideoRedo")> 
<Assembly: AssemblyDescription("Cut Recordings with VideoRedo frameaccurate")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("MyVideoRedo")> 
<Assembly: AssemblyCopyright("Copyright ©  2010-2015")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("16778b8f-b762-4a41-b6d3-c3d25f509af0")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.9.1.3")> 
<Assembly: AssemblyFileVersion("0.9.1.3")> 
