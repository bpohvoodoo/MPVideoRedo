﻿Public Class StandardCutBar
    Inherits ProgressBase



End Class
